export const SIGNIN = "SIGNIN";
export const SIGNOUT = "SIGNOUT";
export const COMMENTS = "COMMENTS";
export const GAMEID = "GAMEID";
