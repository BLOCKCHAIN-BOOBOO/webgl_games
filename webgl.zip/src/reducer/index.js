import { combineReducers } from "redux";
import userToken from "./Signin";
import GameiD from "./GameIds"
export default combineReducers({
  userToken,
  GameiD,
});
