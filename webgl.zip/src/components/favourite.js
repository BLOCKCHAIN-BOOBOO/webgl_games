import React from "react";

const Favourite = () => {
  return <div className="flex justify-center">Favourite</div>;
};

export default Favourite;
