
import React from "react";

const Settings = () => {
return (

<div className="flex">
    Settings

</div>

);
};
    
export default Settings;